UTEID: mmd2468; mjr2595;
FIRSTNAME: Mattthew; Michael;
LASTNAME: Davidson; Raymond;
CSACCOUNT: mattd; mjr2595;
EMAIL: matthew.davidson@utexas.edu; michaeljohnraymond@gmail.com;

[Program 5]
[Description]
There are 3 java files: PasswordCrack.java, User.java, and jcrypt.java. We decided to create a User object that holds all necessary information about a user such as username, first/last name, hash, and seed. The constructor for this object takes in a line of text from the password file and uses the split function to extract the data. We felt it was easiest to keep the track of all dictionary words (and subsequent mangled versions) in an ArrayList as well as keep an ArrayList of Users for iteration. We split up the string manipulations in three levels: 1 being the most trivial, and so forth. To run our program, you need to use "java PasswordCrack dictionary passwords”.

[Finish]
We finished all of this assignment.

[Test Cases]
[Input of test 1]
https://www.cs.utexas.edu/~byoung/cs361/passwd1

[Output of test 1]
We can crack 18 cases in 3.91 minutes.
List of cracked: 
michael
42.00ms
liagiba
67.00ms
Salizar
110.00ms
abort6
233.00ms
amazing
454.00ms
eeffoc
1329.00ms
rdoctor
1819.00ms
doorrood
1839.00ms
enoggone
2303.00ms
Impact
2499.00ms
keyskeys
2678.00ms
obliqu3
3030.00ms
sATCHEL
3506.00ms
squadro
3682.00ms
THIRTY
3797.00ms
icious
3895.00ms
teserP
216722.00ms
sHREWDq
234824.00ms

We can not crack 2 cases.
List of uncracked:
litpeR
hI6d$pC2

[Input of test 2]
https://www.cs.utexas.edu/~byoung/cs361/passwd2

[Output of test 2]
We can crack 15 cases in 11.003 minutes.
List of cracked: 
ElmerJ
116.00ms
^bribed
1032.00ms
dIAMETER
1892.00ms
enchant$
2187.00ms
eltneg
2563.00ms
INDIGNIT
2911.00ms
Saxon
4430.00ms
tremors
5027.00ms
ellows
5282.00ms
soozzoos
5292.00ms
zoossooz
5292.00ms
nosral
7042.00ms
Lacque
426731.00ms
Swine3
632991.00ms
uPLIFTr
660200.00ms
